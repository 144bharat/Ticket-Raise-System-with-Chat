<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        .column {
  float: left;
  width: 50%;
  padding: 0 5px;
}

.row {margin: 100px 250px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 10px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #e2ddcf;
  color: #2A3F54;
}

.fa {font-size:50px;}

.zoom {
  transition: transform .2s;
  margin: 0 auto;
}

.zoom:hover {
  -ms-transform: scale(1.2); /* IE 9 */
  -webkit-transform: scale(1.2); /* Safari 3-8 */
  transform: scale(1.2); 
  padding:0px 30px;
}
:root {
  --animate-duration: 10s;
}



.container2{
  position: absolute;
  top: 70%;
  left: 50%;
  transform: translate(-50%,-50%) rotateX(70deg);
}
.ripple{
  position: fixed;
  top: 0;
  transform: translateX(-50%);

  width: 20px;
  height: 20px;
  border-radius: 50%;
  animation: ripple 4s linear infinite;
}
.r2{
  animation-delay: 0.8s;
}
.r3{
  animation-delay: 1.6s;
}
.r4{
  animation-delay: 2.4s;
}
.r5{
  animation-delay: 3.2s;
}
.r6{
  animation-delay: 4s;
}

@keyframes ripple {
  from{
    border: 4px solid #fff;
    /* background: white; */
    background: rgb(238,174,202);
background: radial-gradient(circle, rgba(238,174,202,1) 0%, rgba(148,187,233,1) 100%);
  }
  to{
    border: 0px solid #fff;
    background: white;
    width: 400px;
    height: 400px;
    top: 20px;
    opacity: 0;
  }
}

    </style>
</head>
<body style="background-color:#2A3F54;color:white;">
    <div class="container">
    <center>
        <h1>Bharat Mini Dashboard</h1>
        <h2 class="animate__animated animate__rubberBand animate__fast" id="typee">Select One Option:</h2>
    </center>


        <div class="row">
            <div class="column zoom" onclick="location.href='credential/adminlog.php';">
                <div class="card">
                <p><i class="fa fa-user"></i></p>
                <h3>11+</h3>
                <p>Admin</p>
                </div>
            </div>

            <div class="column zoom" onclick="location.href='credential/usersign.php';">
                <div class="card">
                <p><i class="fa fa-user"></i></p>
                <h3>55+</h3>
                <p>Users</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container2">
      <span class="ripple r1"></span>
      <span class="ripple r2"></span>
      <span class="ripple r3"></span>
      <span class="ripple r4"></span>
      <span class="ripple r5"></span>
      <span class="ripple r6"></span>
    </div>
</body>
</html>